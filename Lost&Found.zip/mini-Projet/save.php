<?php



if (isset($_GET['nom']) && isset($_GET['prenom'])) {
    $nom_f = $_GET['nom'];
    $prenom_f = $_GET['prenom'];

}

if (isset ($_POST['valider']))
{

    
if (($_FILES['image']['name'] != "")) {
// Where the file is going to be stored
    $target_dir = "C:/Users/Dell/Desktop/mini-Projet/images/";
    $file = $_FILES['image']['name'];
    $path = pathinfo($file);
    $filename = $path['filename'];
    $ext = $path['extension'];
    $temp_name = $_FILES['image']['tmp_name'];
    $path_filename_ext = $target_dir . $filename . "." . $ext;

// Check if file already exists
    if (file_exists($path_filename_ext)) {
        echo "Sorry, file already exists.";
    } else {
        move_uploaded_file($temp_name, $path_filename_ext);
        echo "Congratulations! File Uploaded Successfully.";
    }
}


    $categ=$_POST['categ'];
    $desc=$_POST['desc'];
 $lieu=$_POST['lieu'];
 echo $_SESSION['nom'];

 include "connexion.php";

$RandomNum = time();
$ImageName = str_replace(' ', '-', strtolower($_FILES['image']['name']));
$ImageType = $_FILES['image']['type'];

$ImageExt = substr($ImageName, strrpos($ImageName, '.'));
$ImageExt = str_replace('.', '', $ImageExt);
$ImageName = preg_replace("/\.[^.\s]{3,4}$/", "", $ImageName);
$NewImageName = $ImageName .'.'. $ImageExt;


 $req = "select count(*) from objets ;";
$num=$mysqli->query($req);
 $Num = $num->fetch_array()['count(*)'] ?? ''; 
$nb=(int)$Num+1;
        if( $categ & $desc & $lieu)
        {

            $requete="insert into objets values('$nb','$categ','$lieu','$desc','$NewImageName','$nom_f','$prenom_f')";

            $res = $mysqli->query($requete);
        header("location:home.php");

         }
  }
?>