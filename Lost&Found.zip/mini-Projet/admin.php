
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <a href="delete.php?nom=<?php echo $nom_f;?>&prenom=<?php echo $prenom_f;?>&desc=<?php echo $desc;?>" style="color: red; border: none; background: none;font-size: larger; float: right;"><i class="far fa-trash-alt fa-2x"></i></a>
</body>
</html>