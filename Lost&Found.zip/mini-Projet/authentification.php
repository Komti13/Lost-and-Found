<?php
if (isset($_POST['valider'])) {

    $login = $_POST['log'];
    $pw = $_POST['password'];

    include "connexion.php";
    if ($login & $pw) {

        $requete = "select mail from user where mail='$login'";

        $res = $mysqli->query($requete);
        if ($res->num_rows) {
            $req = "select * from user where mail='$login' and Password='$pw'";

            $result = $mysqli->query($req);
            if ($result->num_rows) {
                $reqN = "select nom from user where mail='$login' and Password='$pw'";
                $reqT = "select numtel from user where mail='$login' and Password='$pw'";
                $reqPnom = "select prenom from user where mail='$login' and Password='$pw'";
                $execN = $mysqli->query($reqN);
                $execT = $mysqli->query($reqT);
                $execPnom = $mysqli->query($reqPnom);

                $Nom = $execN->fetch_array()['nom'] ?? '';
                $Tel = $execT->fetch_array()['numtel'] ?? '';
                $Prenom = $execPnom->fetch_array()['prenom'] ?? '';

                session_start();
                $_SESSION["nom"] = $Nom;
                $_SESSION["numtel"] = $Tel;
                $_SESSION["prenom"] = $Prenom;
                $_SESSION["login"] = $login;
                $_SESSION["mdp"] = $pw;

                header("location:home.php");

            }
        } else {
            echo "utilisateur introuvale";
        }

    }

}
?>
<html>
    <link rel="stylesheet" href="style1.css">
<head>
<title>Login</title>
 <link rel="icon" type="image/ico" href="images/gps.png">
</head>

<body>
    <form method="POST" action="authentification.php">
    <div class="login-box">
  <h1>Login</h1>
  <div class="textbox">
    <i class="fas fa-user"></i>
    <input type="text" placeholder="Nom utilisateur" name="log" required>
  </div>

  <div class="textbox">
    <i class="fas fa-lock"></i>
    <input type="password" placeholder="Mot de passe" name="password" required>
  </div>

  <input type="submit" class="btn" value="Valider" name="valider"><br><br><br><br>

   <a href="inscription.php" style="text-decoration: none;"><i class="fas fa-user-plus"></i> Inscrivez-vous!</a>
    <a href="guest.php" style="float: right; text-decoration: none;">Visiteur <i class="fas fa-eye"></i></i></a>
</div>

</form>
</body>
</html>
