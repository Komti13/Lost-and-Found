<?php  
include "connexion.php";
 $requete="select * from objets ";
 $res = $mysqli->query($requete);
if ($res->num_rows){
    while ($row = $res->fetch_assoc()) {
        $id= $row["numero"];
        $categ = $row["categorie"];
        $desc = $row["description"];
         $nom_f = $row["nom_fondateur"];
         $prenom_f = $row["prenom_fondateur"];
         $img= $row["image"];
        $lieu=$row["lieu"];
        if ($type=="Electronique" && $categ==$type) {
            include "objet.php";

        }
        if ( $type=="Document" && $categ==$type) {
         
            include "objet.php";

        }
        if ( $type=="Vetements" && $categ==$type) {
            include "objet.php";

        }
        if ( $type=="Autres Objets" && $categ==$type) {
            include "objet.php";

        }


}

}
?>