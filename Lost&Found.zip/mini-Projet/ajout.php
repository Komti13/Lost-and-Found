<html>
       <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <!-- Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/css/mdb.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style3.css">
<head>
    <title>Ajouter</title>
     <link rel="icon" type="image/ico" href="images/gps.png">
</head>
<body>
   <?php 
   if (isset($_GET['nom']) && isset($_GET['prenom'])) {
    $nom = $_GET['nom'];
    $prenom = $_GET['prenom'];

}

   ?>
<form method="POST" action="save.php?nom=<?php echo $nom?>&prenom=<?php echo $prenom?>" enctype="multipart/form-data">
    
       <div class="signin-box">
           <h1>Ajouter</h1>
            <div class="textboxC    ">
                <label for="categ">Categorie:</label>
  
<div class="form-group" id="sel1"  >
  <select class="form-control" name="categ" required>
    <option value="">------</option>
    <option value="Electronique">Electronique</option>
    <option value="Document">Document</option>
    <option value="Vetements">Vetements</option>
    <option value="Autres Objets">Autres Objets</option>
  </select>
</div>
    </div>
     <div class="textboxC">
         <label for="desc">Description:</label>
     <input type="text" name="desc" placeholder="decrire en deux mots l'objet trouvé" required/>
    </div>
     <div class="textboxC">
         <label for="lieu">Lieu ou est trouvé:</label>
     <input type="text" name="lieu" placeholder="donner le lieu exacte ou vous avez trouvez cet objet"required/>
    </div>
  
<label for="image">importer une image:</label>
    <input type="file" name="image" required />  



    <input type="submit" name="valider"  class="btnC" value="Ajouter"/>
    <a href="home.php"> Retour à la page d'acceuil</a>
    </div>
</form>


 <!-- JQuery -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/js/mdb.min.js"></script>
</body>
</html>
