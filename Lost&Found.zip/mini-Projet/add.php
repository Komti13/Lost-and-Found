  
  <?php
  if ($_SESSION['nom']!='Login'){
      $nom_f=$_SESSION['nom'];
      $prenom_f=$_SESSION['prenom'];

    echo " <a href='ajout.php?nom=$nom_f&prenom=$prenom_f'>
                
                <p id='parag'><i id='shoppingCart' class='fas fa-plus p-2'></i>add</p>
            </a>";
  }
  
  
  ?>
  
  
  