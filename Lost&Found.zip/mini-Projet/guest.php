<?php
session_start();

$_SESSION['nom']="Login";
header("location:home.php");



?>