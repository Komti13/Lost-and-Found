<?php
$host='localhost';
$root='root';
$mdp='';
$db='lost and found';
/*
//connexion procédurale
$connexion = mysqli_connect($host,$root,$mdp) or die("erreur");
$con=mysqli_select_db($connexion,$db) or die("Base introuvable");
//mode Orienté objet*/


$mysqli = new mysqli($host,$root, $mdp, $db);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}



//PDO
// $pdo = new PDO("mysql:host=localhost;dbname=test", $root, $mdp);
// $pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, true);//or true

//echo(mysqli_get_client_info());*/

?>