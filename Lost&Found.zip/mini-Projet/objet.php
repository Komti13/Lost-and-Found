<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
       <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <!-- Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/css/mdb.min.css" rel="stylesheet">
    <link rel="stylesheet" href="test.css">
    <script src="test.js"></script>
</head>
<body>
    <?php

       $req = "select * from user where nom='$nom_f' and prenom='$prenom_f'";
        $result = $mysqli->query($req);
        if ($result->num_rows) {
            $numtel = $result->fetch_array()['numtel'] ?? '';
            $fb = $result->fetch_array()['nom'] ?? '';

}

    
    ?>
      <a class=" item" href="article.php?nom=<?php echo $nom_f;?>&prenom=<?php echo $prenom_f;?>&desc=<?php echo $desc;?>&numtel=<?php echo $numtel;?>&fb=<?php echo $fb;?>&lieu=<?php echo $lieu;?>&img=<?php echo $img;?>&log=<?php echo $log;?>">
               
                   <!-- <input name="del" type="submit" value="X"  style="color: red; border: none; background: none; float: right; font-size: larger;"> -->
                    <img src=<?php echo "images/".$img?> class="logoImg"  alt="">
                    <h4 class="mt-2 text-center"><?php  echo $desc;  ?></h4>
                     
                </a>

</form>
                 <!-- JQuery -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/js/mdb.min.js"></script>

</body>
</html>