
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
       <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <!-- Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/css/mdb.min.css" rel="stylesheet">
    <link rel="stylesheet" href="test.css">
    <script src="test.js"></script>
</head>
<body>
    <?php
if (isset($_GET['nom']) && isset($_GET['prenom'])) {
    $nom_f = $_GET['nom'];
    $prenom_f = $_GET['prenom'];
    $numtel = $_GET['numtel'];
    $desc = $_GET['desc'];
    $lieu = $_GET['lieu'];
    $img = $_GET['img'];
    $log = $_GET['log'];



   include "connexion.php";

     $req="select * from user where nom='$nom_f' and prenom='$prenom_f'" ;
                $result = $mysqli->query($req);
                    if ($result->num_rows){
                        $fb=$result->fetch_array()['fb'] ?? '';
              

                    }

}
?>
         <div class="" style="width: 100%; height: 50%;">
<div class="card m-3">
  <img class="card-img-top" src=<?php echo "images/" . $img ?> alt="Card image cap" style="height: 300px; width: 300px; margin-left: auto; margin-right: auto;">
  <div class="card-body">
    <h5 class="card-title"><?php echo $desc ?></h5>
    <p class="card-text">Trouvé chez <?php echo $lieu?></p>
    <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
  </div>
  <ul class="list-group list-group-flush">
   
    <li class="list-group-item" style="color: red;">Coordonnées du fondateur:</li>
     <li class="list-group-item"><i class="fas fa-user" style="color: blue;"></i><?php echo '   '.$nom_f.'  '.$prenom_f ?></li>
    <li class="list-group-item"><i class="fas fa-phone" style="color: green;"></i>  <?php echo '   '.' Telephone ' . $numtel ?>
</li>
  </ul>
   <div class="card-body">
    <a href="home.php" class="card-link" style="color: #2a57ec;"><i class="fas fa-arrow-left fa-2x"></i></a>
    <a href="<?php  echo $fb; ?>" class="card-link" style="color: #2a57ec; "><i class="fab fa-facebook fa-2x"></i></a>
    <?php  
      if ($log=="admin") {
        include "admin.php";

      }
     ?>
  </div>
</div>
</div>







             <!-- JQuery -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/js/mdb.min.js"></script>
</body>
</html>