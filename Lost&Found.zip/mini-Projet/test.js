
window.addEventListener("scroll", () => {
    if (window.scrollY > 500) {
    //    rgb(147,168,6)
        document.getElementById("nav").style.backgroundColor="white";
          document.getElementById("navigation").style.color="rgb(42,87,236)";
        document.getElementById("navigation1").style.color="rgb(42,87,236)";
    } 
    if (window.scrollY < 500) {
        document.getElementById("nav").style.background="none";
        document.getElementById("navigation").style.color="white";
        document.getElementById("navigation1").style.color="white";
    }
  });