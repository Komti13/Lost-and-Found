<?php
if (isset ($_POST['valider']))
{
    $name=$_POST['nom'];
    $pren=$_POST['prenom'];
    $login=$_POST['log'];
    $pw=$_POST['pw'];
    $repw=$_POST['rpw'];
    $fblink = $_POST['fblink'];
    $tel = $_POST['tel'];

    if($name & $pren & $login & $pw & $repw & $fblink & $tel)
    {
        if ($pw==$repw)
        {
            include "connexion.php";

            $requete="insert into user values('$name','$pren','$login','$pw','$fblink','$tel')";
         
          
            if (!$mysqli->query($requete))
            {echo "Insertion échouée: (" . $mysqli->errno . ") " . $mysqli->error;}
            else {
                header("location:authentification.php");

            }

        }

        else
            echo "les deux mots de passe ne sont pas identiques";
    }
    else
        echo "veuillez remplir tous les champs";
}



?>
<html>
    <link rel="stylesheet" href="style2.css">
<head>
     <title>Inscription</title>
      <link rel="icon" type="image/ico" href="images/gps.png">
</head>
<body>
<form method="POST" action="inscription.php">
    
       <div class="signin-box">
           <h1>S'inscrire</h1>
            <div class="textboxC">
                <label for="nom">Nom:</label>
     <input type="text" name="nom" placeholder="Ecrivez votre nom" required/>
    </div>
     <div class="textboxC">
         <label for="prenom">Prenom:</label>
     <input type="text" name="prenom" placeholder="Ecrivez votre prenom" required/>
    </div>
     <div class="textboxC">
         <label for="log">Login:</label>
     <input type="text" name="log" placeholder="Nom Utilisateur"required/>
    </div>
     <div class="textboxC">
         <label for="pw">Password:</label>
     <input type="password" name="pw" placeholder="Ecrivez votre Mot de passe" required/>
    </div>
     <div class="textboxC">
         <label for="rpw">Retype Password:</label>
     <input type="password" name="rpw" placeholder="Reecrivez votre Mot de passe" required/>
    </div>
     <div class="textboxC">
         <label for="fblink">Lien facebook:</label>
     <input type="text" name="fblink" placeholder="Coller ici le lien vers votre profile Facebook" required/>

     </div>
      <div class="textboxC">
          <label for="tel">numero telephone:</label>
     <input type="text" name="tel" placeholder="Ecrivez votre Numero de telephone" required/>
     </div>



    <input type="submit" name="valider"  class="btnC" value="Créer"/><br><br><br>
    <a href="authentification.php" style="text-decoration: none;"> Vous avez déja un compte <i class="fas fa-sign-in-alt"></i></a>
    </div>
</form>
</body>
</html>
