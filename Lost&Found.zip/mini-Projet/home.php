<?php
session_start(); 
   if (!isset($_SESSION['nom']))  {
         header("location:authentification.php");
   }      
   if (isset($_SESSION['login'])) {

if ($_SESSION["login"]=="admin" && $_SESSION["mdp"]=="admin") {
    $log="admin";
}
else {
    $log="normal";
}
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lost & Found</title>
    <link rel="icon" type="image/ico" href="images/gps.png">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <!-- Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/css/mdb.min.css" rel="stylesheet">
    <link rel="stylesheet" href="test.css">
    <script src="test.js"></script>
</head>

<body class=" text-dark">

    <nav class="fixed-top " id="nav" style="height: 100px;">
        <div style="height: 100%; width: 100%; color: black;" class="d-flex justify-content-between">
         
        
            
             <a href="authentification.php">
               
                <p id="parag">
                   <i id="shoppingCart" class="fas fa-user p-2"></i>
                     <?php echo $_SESSION["nom"] ?>
            </p>
            </a>
            <img src="images/officiallogo.png" alt="" style="height: 200px;">
            <a href="#footer" id="navigation">Conact</a>
            <a href="#footer" id="navigation1">About Us</a>
      <a href="">
              <?php
            $name=$_SESSION["nom"];
                include "add.php";
                ?>
</a>
        </div>
    </nav>
<div class="">
        <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img class="d-block w-100" src="images/lost&found.jpg" style="height: 75vh; width: auto;"
                  alt="First slide">
                     <div class="carousel-caption d-none d-md-block">
                <h1 style="color:#120078; font-size: 2cm; ">Lost & Found</h1>
                <p style="color:#120078; font-size: x-large;">Si vous avez perdu quelque chose vous la trouvez là !!</p>
                </div>
              </div>
               <div class="carousel-item ">
                <img class="d-block w-100"  src="images/banner2.png" alt="Second slide" style="height: 75vh; width: auto;"> 
                 <div class="carousel-caption d-none d-md-block">
                
                </div>
              </div>
              <div class="carousel-item ">
                <img class="d-block w-100"  src="images/help.jpg" alt="Second slide" style="height: 75vh; width: auto;"> 
                 <div class="carousel-caption d-none d-md-block">
                
                </div>
              </div>
                <div class="carousel-item ">
                <img class="d-block w-100"  src="images/phones banner.jpeg" alt="third slide" style="height: 75vh; width: auto;"> 
                 <div class="carousel-caption d-none d-md-block">
                
                </div>
              </div>
              <div class="carousel-item ">
                <img class="d-block w-100"  src="images/unnamed.jpg" alt="Second slide" style="height: 75vh; width: auto;"> 
                 <div class="carousel-caption d-none d-md-block">
                
                </div>
              </div>
              <div class="carousel-item ">
                <img class="d-block w-100"  src="images/banner1.png" alt="Second slide" style="height: 75vh; width: auto;"> 
                 <div class="carousel-caption d-none d-md-block">
                
                </div>
              </div>
              <div class="carousel-item ">
                <img class="d-block w-100"  src="images/existBanner.jpg" alt="Second slide" style="height: 75vh; width: auto;"> 
                 <div class="carousel-caption d-none d-md-block">
                
                </div>
              </div>
              <div class="carousel-item ">
                <img class="d-block w-100"  src="images/bannerClothes.jpg" alt="Second slide" style="height: 75vh; width: auto;"> 
                 <div class="carousel-caption d-none d-md-block">
                
                </div>
              </div>
            
              <div class="carousel-item ">
                <img class="d-block w-100"  src="images/documents-banner.jpg" alt="Second slide" style="height: 75vh; width: auto;"> 
                 <div class="carousel-caption d-none d-md-block">
                
                </div>
              </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleControls" role="a" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleControls" role="a" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </a>
          </div>
          </div>


         <div class="p-3">
        <!-- foods -->
        <div class="mt-2 ">
            <div class="d-flex justify-content-between ">
                <h2>Electroniques </h2>
                <h4 class="mt-1 pr-2"><i class="fas fa-arrow-right"></i></h4>

            </div>
            <div class="scrollmenu" style="width: 100%;  padding: 20px;">
                <!-- <a  class=" item" href='article.php?type=true'>
                    <img src="images/baguette.jpg" class="logoImg"  alt="">
                    <h4 class="mt-2 text-center">Baguette & Baguette</h4>
                </a>
                <a class=" item" href='article.php?type=true'>
                    <img src="images/king.png" class="logoImg"  alt="">
                    <h4 class="mt-2 text-center">Buger King</h4>
                </a>
                <a class=" item" href='article.php?type=true'>
                    <img src="images/chilis.jpeg" class="logoImg"  alt="">
                    <h4 class="mt-2 text-center">Chili's</h4>
                </a>
                <a class=" item" href='article.php?type=true'>
                    <img src="images/kfc.png" class="logoImg"  alt="">
                    <h4 class="mt-2 text-center">KFC</h4>
                </a><a  class=" item" href='article.php?type=true'>
                    <img src="images/baguette.jpg" class="logoImg"  alt="">
                    <h4 class="mt-2 text-center">Baguette & Baguette</h4>
                </a> -->


            <?php
            $type = "Electronique";
            include "addobject.php";
            ?>


            </div>
        </div>

        <!-- shops -->
        <div class="mt-2 ">
            <div class="d-flex justify-content-between">
                <h2>Documents </h2>
                <h4 class="mt-1 pr-2"><i class="fas fa-arrow-right"></i></h4>

            </div>
            <div class="scrollmenu" style="width: 100%; padding: 20px;">
                <!-- <a class=" item" href='article.php?type=true'>
                    <img src="images/phone.jpg" class="logoImg"  alt="">
                    <h4 class="mt-2 text-center">Aldo</h4>
                </a>
                <a class=" item" href='article.php?type=true'>
                    <img src="images/pc.jpg" class="logoImg"  alt="">
                    <h4 class="mt-2 text-center">Celio</h4>
                </a>
                <a class=" item" href='article.php?type=true'>
                    <img src="images/elec.jpg" class="logoImg"  alt="">
                    <h4 class="mt-2 text-center">Exist</h4>
                </a>
                <a class=" item" href='article.php?type=true'>
                    <img src="images/bershka.jpg" class="logoImg"  alt="">
                    <h4 class="mt-2 text-center">Bershka</h4>
                </a>
                 <a class=" item" href='article.php?type=true'>
                    <img src="images/exist.png" class="logoImg"  alt="">
                    <h4 class="mt-2 text-center">Exist</h4>
                </a>
                <a class=" item" href='article.php?type=true'>
                    <img src="images/bershka.jpg" class="logoImg"  alt="">
                    <h4 class="mt-2 text-center">Bershka</h4>
                </a>
                 <a class=" item" href='article.php?type=true'>
                    <img src="images/exist.png" class="logoImg"  alt="">
                    <h4 class="mt-2 text-center">Exist</h4>
                </a>
                <a class=" item" href='article.php?type=true'>
                    <img src="images/bershka.jpg" class="logoImg"  alt="">
                    <h4 class="mt-2 text-center">Bershka</h4>
                </a> -->
          <?php
            $type = "Document";
            include "addobject.php";
            ?>
            </div>
        </div>

        <!-- Electronics -->
        <div class="mt-2 ">
            <div class="d-flex justify-content-between">
                <h2>Vetements </h2>
                <h4 class="mt-1 pr-2"><i class="fas fa-arrow-right"></i></h4>

            </div>
            <div class="scrollmenu" style="width: 100%;  padding: 20px;">
                <!-- <a class=" item" href='article.php?type=true'>
                    <img src="images/fnac.jpg" class="logoImg"  alt="">
                    <h4 class="mt-2 text-center">Fnac</h4>
                </a>
                <a class=" item" href='article.php?type=true'>
                    <img src="images/darty.png" class="logoImg"  alt="">
                    <h4 class="mt-2 text-center">Darty</h4>
                </a>
                 <a class=" item" href='article.php?type=true'>
                    <img src="images/fnac.jpg" class="logoImg"  alt="">
                    <h4 class="mt-2 text-center">Fnac</h4>
                </a>
                <a class=" item" href='article.php?type=true'>
                    <img src="images/darty.png" class="logoImg"  alt="">
                    <h4 class="mt-2 text-center">Darty</h4>
                </a> -->
      <?php
$type = "Vetements";
include "addobject.php";
?>
            </div>
        </div>

        <!-- Leisure -->
        <div class="mt-2 ">
            <div class="d-flex justify-content-between">
                <h2>Autres Objets </h2>
                <h4 class="mt-1 pr-2"><i class="fas fa-arrow-right"></i></h4>

            </div>
            <div class="scrollmenu" style="width: 100%; padding: 20px;">
                <!-- <a class=" item" href='article.php?type=true'>
                    <img src="images/pathe.png" class="logoImg"  alt="">
                    <h4 class="mt-2 text-center">Le Pathé</h4>
                </a>
                <a class=" item" href='article.php?type=true'>
                    <img src="images/kidi.jpeg" class="logoImg"  alt="">
                    <h4 class="mt-2 text-center">Kidi Park</h4>
                </a>
                 <a class=" item" href='article.php?type=true'>
                    <img src="images/pathe.png" class="logoImg"  alt="">
                    <h4 class="mt-2 text-center">Le Pathé</h4>
                </a>
                <a class=" item" href='article.php?type=true'>
                    <img src="images/kidi.jpeg" class="logoImg"  alt="">
                    <h4 class="mt-2 text-center">Kidi Park</h4>
                </a>
                 <a class=" item" href='article.php?type=true'>
                    <img src="images/pathe.png" class="logoImg"  alt="">
                    <h4 class="mt-2 text-center">Le Pathé</h4>
                </a>
                <a class=" item" href='article.php?type=true'>
                    <img src="images/kidi.jpeg" class="logoImg"  alt="">
                    <h4 class="mt-2 text-center">Kidi Park</h4>
                </a> -->
      <?php
$type = "Autres Objets";
include "addobject.php";
?>
            </div>
        </div>

    </div>

<footer id="footer" class="footer">
    <div class="row footrow">
        <div class="col-md-6">
            <div class="footerleft">
                <h2>21 Revolution Street Sousse</h2>
                <h1>Sousse ,Tunisie</h1>
                <h1>+1 555 123456</h1>
                <h2>komti316@gmail.com</h2>
                <div class="d-flex justify-content-between" style="width: 30%;">
                     <a  aria-hidden="true" href="https://www.facebook.com/komti/" style="font-size: xx-large;"><i class="fab fa-instagram"></i></a>
                <a aria-hidden="true" href="https://www.instagram.com/komti_abd/" style="font-size: xx-large;"><i class="fab fa-facebook-f"></i></a>
                <a aria-hidden="true" href="https: //twitter.com/AbdKomti" style="font-size: xx-large;"><i class="fab fa-twitter"></i></a>
                </div>
               
            </div>
        </div>
        <div class="col-md-4">
            <div class="footerright">
                <h2>About the company</h2>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Amet mollitie
                    accusamus praesentium quisquam tenetur, distinctio, ad a sequi atque repudiandae aliquid molestiae!
                    Cum
                    voluptate voluptatum quo
                    quod consectetur voluptatem quam!</p>
                    &#169; Komti Abdelkader
            </div>

        </div>

    </div>

</footer>
 <!-- JQuery -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/js/mdb.min.js"></script>

</body>
</html>
