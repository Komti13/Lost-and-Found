<?php
if (isset($_GET['nom']) && isset($_GET['prenom']) && isset($_GET['desc'])) {
    $nom_f = $_GET['nom'];
$prenom_f = $_GET['prenom'];
$desc = $_GET['desc'];

    include "connexion.php";

      $reqdel="delete from objets where nom_fondateur='$nom_f' and prenom_fondateur='$prenom_f' and description='$desc'";
      $res = $mysqli->query($reqdel);
      header("location:home.php");
 

}




?>